Protocol incontext-natural-block-float32

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| Pythia-70M | AR decoder | 6 | 0.419 | 0.40-0.44 | 3.82 | yes | 0.216 | 0.318 | 30.887 |
| GPT-2 124M | AR decoder | 12 | 0.713 | 0.67-0.75 | 1.49 | yes | 0.780 | 0.258 | 10.479 |
| Pythia-160M | AR decoder | 12 | 0.759 | 0.71-0.81 | 1.89 | yes | 0.884 | 0.252 | 20.097 |
| Pythia-410M | AR decoder | 24 | 0.839 | 0.81-0.87 | 1.30 | no | 0.807 | 0.189 | 4.469 |
| Qwen2.5-0.5B | AR decoder | 24 | 0.881 | 0.86-0.91 | 1.00 | no | 0.732 | 0.200 | 5.434 |
| GPT-2 Large | AR decoder | 36 | 0.915 | 0.89-0.94 | 1.09 | no | 0.754 | 0.241 | 5.305 |
| Pythia-1B | AR decoder | 16 | 0.806 | 0.78-0.84 | 1.31 | no | 0.834 | 0.158 | 4.316 |
| Llama-3.2-1B | AR decoder | 16 | 0.815 | 0.79-0.84 | 1.10 | no | 0.650 | 0.291 | 12.153 |
| Pythia-1.4B | AR decoder | 24 | 0.705 | 0.67-0.74 | 1.75 | yes | 0.646 | 0.420 | 12.961 |
| Qwen2.5-1.5B | AR decoder | 28 | 0.856 | 0.82-0.89 | 1.04 | no | 0.774 | 0.319 | 10.159 |
| GPT-2 XL | AR decoder | 48 | 0.919 | 0.89-0.95 | 1.11 | no | 0.935 | 0.340 | 3.751 |
| Gemma-2-2B | AR decoder | 26 | 0.962 | 0.93-0.99 | 1.05 | no | 1.012 | 0.073 | 3.697 |
| Phi-2 | AR decoder | 32 | 0.802 | 0.78-0.82 | 1.22 | no | 0.688 | 0.362 | 7.291 |
| Pythia-2.8B | AR decoder | 32 | 0.785 | 0.75-0.82 | 1.41 | yes | 0.748 | 0.284 | 6.142 |
| Qwen2.5-3B | AR decoder | 36 | 0.915 | 0.88-0.95 | 0.99 | no | 0.921 | 0.047 | 0.763 |
| Llama-3.2-3B | AR decoder | 28 | 0.971 | 0.94-1.00 | 0.81 | no | 0.689 | 0.094 | 5.711 |
| Pythia-6.9B | AR decoder | 32 | 0.800 | 0.77-0.83 | 1.39 | yes | 0.725 | 0.330 | 9.984 |
| Mistral-7B | AR decoder | 32 | 0.918 | 0.90-0.94 | 0.83 | no | 0.604 | 0.147 | 5.664 |
| Qwen2.5-7B | AR decoder | 28 | 0.753 | 0.72-0.78 | 1.28 | yes | 0.720 | 0.384 | 18.229 |
| Pythia-12B | AR decoder | 36 | 0.934 | 0.90-0.97 | 1.16 | no | 0.940 | 0.129 | 3.598 |
| Qwen2.5-14B | AR decoder | 48 | 0.972 | 0.94-1.01 | 0.97 | no | 0.818 | 0.103 | 5.393 |
| Whisper-small | Audio encoder | 12 | 0.860 | 0.82-0.91 | 1.50 | no | 0.599 | 0.176 | 2.398 |
| ConvNeXt-tiny | ConvNet (vision) | 18 | 0.351 | 0.34-0.36 | 3.88 | yes | 0.373 | 0.697 | 29.340 |
| ConvNeXt-small | ConvNet (vision) | 36 | 0.580 | 0.55-0.61 | 1.86 | yes | 0.410 | 0.498 | 14.636 |
| ConvNeXt-base | ConvNet (vision) | 36 | 0.490 | 0.46-0.52 | 1.95 | yes | 0.369 | 0.533 | 25.994 |
| ConvNeXt-large | ConvNet (vision) | 36 | 0.516 | 0.48-0.56 | 2.40 | yes | 0.338 | 0.408 | 24.707 |
| BERT-base | Masked encoder | 12 | 0.968 | 0.93-1.01 | 0.99 | no | 0.901 | 0.036 | 0.283 |
| RoBERTa-base | Masked encoder | 12 | 1.132 | 1.09-1.17 | 0.77 | no | 0.978 | -0.134 | -5.731 |
| Mamba-130M | SSM | 24 | 0.514 | 0.49-0.54 | 2.62 | yes | 0.551 | 0.645 | 29.793 |
| Mamba-1.4B | SSM | 48 | 0.907 | 0.86-0.95 | 1.23 | no | 1.209 | 0.282 | 2.710 |
| Mamba-2.8B | SSM | 64 | 0.918 | 0.88-0.95 | 1.20 | no | 1.125 | 0.429 | 4.214 |
| DINOv2-base | Vision SSL | 12 | 0.769 | 0.73-0.81 | 1.50 | yes | 0.492 | 0.232 | 13.508 |
| ViT-base | Vision supervised | 12 | 0.806 | 0.68-0.98 | 1.59 | no | 0.826 | 0.231 | 4.449 |
| Qwen2-0.5B | AR decoder | 24 | 0.857 | 0.83-0.89 | 1.02 | no | 0.654 | 0.255 | 6.680 |
| Mistral-7B-Instruct | AR decoder | 32 | 0.924 | 0.90-0.95 | 0.85 | no | 0.599 | 0.146 | 5.830 |
| wav2vec2-base | Audio encoder | 12 | 0.927 | 0.82-1.04 | 1.40 | no | 0.493 | 0.087 | 3.246 |
| T5-small (encoder) | Encoder-decoder | 6 | 1.086 | 0.82-1.57 | 0.82 | no | 1.041 | 0.012 | -3.150 |
| T5-base (encoder) | Encoder-decoder | 12 | 1.008 | 0.92-1.15 | 0.95 | no | 1.018 | -0.005 | -0.246 |
| T5-large (encoder) | Encoder-decoder | 24 | 0.971 | 0.90-1.08 | 1.10 | no | 0.943 | -0.021 | 1.153 |
| Flan-T5-large (encoder) | Encoder-decoder | 24 | 0.216 | 0.09-0.87 | 0.99 | no | 1.059 | -0.027 | 60.066 |
| MLP-Mixer-B | MLP-Mixer (vision) | 12 | 0.550 | 0.43-0.67 | 2.26 | yes | 0.456 | 0.393 | 20.111 |
| MLP-Mixer-L | MLP-Mixer (vision) | 24 | 0.745 | 0.71-0.79 | 1.25 | yes | 0.633 | 0.471 | 10.816 |
| BERT-large | Masked encoder | 24 | 0.992 | 0.95-1.03 | 1.18 | no | 1.143 | -0.060 | -0.951 |
| RoBERTa-large | Masked encoder | 24 | 1.342 | 1.29-1.40 | 0.58 | no | 1.716 | -0.524 | -13.371 |
| Mamba-370M | SSM | 48 | 0.751 | 0.72-0.78 | 1.55 | yes | 0.887 | 0.593 | 11.113 |
