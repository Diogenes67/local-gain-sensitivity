Protocol incontext-random-block-float32-fd

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.713 | 0.69-0.73 | 1.46 | yes | 0.789 | 0.302 | 8.858 |
| Pythia-160M | AR decoder | 12 | 0.685 | 0.66-0.72 | 2.11 | yes | 0.742 | 0.358 | 22.215 |
| Pythia-410M | AR decoder | 24 | 0.836 | 0.80-0.86 | 1.31 | no | 0.895 | 0.296 | 5.605 |
| Pythia-1B | AR decoder | 16 | 0.745 | 0.73-0.76 | 1.31 | yes | 0.796 | 0.331 | 14.292 |
| Pythia-1.4B | AR decoder | 24 | 0.729 | 0.70-0.76 | 1.56 | yes | 0.739 | 0.313 | 9.046 |
| Qwen2.5-1.5B | AR decoder | 28 | 0.895 | 0.88-0.91 | 1.02 | no | 0.962 | 0.323 | 9.117 |
| GPT-2 XL | AR decoder | 48 | 0.953 | 0.94-0.97 | 0.99 | no | 0.840 | 0.350 | 3.925 |
