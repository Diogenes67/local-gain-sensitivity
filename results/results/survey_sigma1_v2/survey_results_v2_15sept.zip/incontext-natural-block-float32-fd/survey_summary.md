Protocol incontext-natural-block-float32-fd

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.706 | 0.67-0.75 | 1.49 | yes | 0.781 | 0.265 | 10.742 |
| Pythia-160M | AR decoder | 12 | 0.754 | 0.71-0.80 | 1.91 | yes | 0.869 | 0.262 | 20.302 |
| Pythia-410M | AR decoder | 24 | 0.838 | 0.80-0.87 | 1.31 | no | 0.806 | 0.190 | 4.495 |
| Pythia-1B | AR decoder | 16 | 0.806 | 0.78-0.84 | 1.31 | no | 0.834 | 0.158 | 4.343 |
| Pythia-1.4B | AR decoder | 24 | 0.658 | 0.62-0.69 | 1.96 | yes | 0.524 | 0.474 | 16.726 |
| Qwen2.5-1.5B | AR decoder | 28 | 0.856 | 0.82-0.89 | 1.04 | no | 0.774 | 0.321 | 10.224 |
| GPT-2 XL | AR decoder | 48 | 0.919 | 0.89-0.95 | 1.11 | no | 0.934 | 0.340 | 3.762 |
