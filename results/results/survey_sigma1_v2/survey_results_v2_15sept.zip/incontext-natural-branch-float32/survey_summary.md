Protocol incontext-natural-branch-float32

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.707 | 0.67-0.75 | 1.50 | yes | 0.774 | 0.263 | 10.884 |
| Pythia-160M | AR decoder | 12 | 0.748 | 0.70-0.80 | 1.92 | yes | 0.869 | 0.266 | 20.373 |
| Pythia-410M | AR decoder | 24 | 0.843 | 0.81-0.87 | 1.28 | no | 0.811 | 0.210 | 4.490 |
| Qwen2.5-0.5B | AR decoder | 24 | 0.900 | 0.88-0.93 | 0.97 | no | 0.728 | 0.184 | 5.131 |
| Pythia-1.4B | AR decoder | 24 | 0.704 | 0.67-0.74 | 1.75 | yes | 0.645 | 0.421 | 12.867 |
| Phi-2 | AR decoder | 32 | 0.814 | 0.79-0.84 | 1.18 | no | 0.692 | 0.354 | 6.941 |
| Qwen2.5-7B | AR decoder | 28 | 0.763 | 0.73-0.79 | 1.27 | yes | 0.732 | 0.384 | 18.145 |
