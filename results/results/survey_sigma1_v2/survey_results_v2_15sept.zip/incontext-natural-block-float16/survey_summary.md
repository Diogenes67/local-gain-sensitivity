Protocol incontext-natural-block-float16

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| Pythia-2.8B | AR decoder | 32 | nan |  | nan | no | nan | nan | nan |
| Pythia-6.9B | AR decoder | 32 | nan |  | nan | no | nan | nan | nan |
| Pythia-12B | AR decoder | 36 | nan |  | nan | no | nan | nan | nan |
