Protocol fullseq-random-block-float32

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.467 | 0.43-0.51 | 2.27 | yes | 0.478 | 0.631 | 119.772 |
| Pythia-160M | AR decoder | 12 | 0.496 | 0.46-0.54 | 2.64 | yes | 0.352 | 0.582 | 81.702 |
| Pythia-410M | AR decoder | 24 | 0.710 | 0.70-0.73 | 1.54 | yes | 0.650 | 0.326 | 12.804 |
| Pythia-1B | AR decoder | 16 | 0.437 | 0.40-0.47 | 1.90 | yes | 0.729 | 0.594 | 42.957 |
| Llama-3.2-1B | AR decoder | 16 | 0.133 | 0.12-0.15 | 1.19 | yes | 0.604 | 0.915 | 1528.154 |
| Pythia-1.4B | AR decoder | 24 | 0.348 | 0.31-0.40 | 4.70 | yes | 0.129 | 0.776 | 230.854 |
| Qwen2.5-1.5B | AR decoder | 28 | 0.086 | 0.08-0.09 | 1.98 | yes | 0.615 | 0.970 | 1439.091 |
| GPT-2 XL | AR decoder | 48 | 0.806 | 0.73-0.88 | 1.31 | no | 0.758 | 0.365 | 19.337 |
| Pythia-6.9B | AR decoder | 32 | 0.566 | 0.52-0.61 | 2.95 | yes | 0.175 | 0.623 | 131.850 |
| Qwen2.5-7B | AR decoder | 28 | 0.065 | 0.06-0.07 | 2.23 | yes | 0.392 | 0.978 | 1201.970 |
| ConvNeXt-tiny | ConvNet (vision) | 18 | 0.370 | 0.36-0.38 | 3.10 | yes | 1.766 | 0.545 | -19.271 |
| ConvNeXt-base | ConvNet (vision) | 36 | 0.356 | 0.35-0.36 | 3.76 | yes | 0.136 | 0.058 | 105.288 |
| Mamba-130M | SSM | 24 | 0.357 | 0.34-0.38 | 4.48 | yes | 0.311 | 0.795 | 110.779 |
