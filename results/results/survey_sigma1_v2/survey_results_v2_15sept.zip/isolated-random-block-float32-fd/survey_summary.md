Protocol isolated-random-block-float32-fd

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.591 | 0.58-0.60 | 2.55 | yes | 1.131 | 0.371 | 54.456 |
| Pythia-160M | AR decoder | 12 | 0.958 | 0.94-0.97 | 1.32 | no | 0.785 | -0.031 | 15.763 |
| Pythia-410M | AR decoder | 24 | 0.857 | 0.83-0.88 | 1.38 | no | 0.796 | 0.197 | 4.412 |
| Pythia-1B | AR decoder | 16 | 0.832 | 0.82-0.84 | 1.19 | no | 0.897 | 0.208 | 11.254 |
| Pythia-1.4B | AR decoder | 24 | 1.012 | 1.00-1.02 | 0.76 | no | 0.604 | 0.086 | 3.424 |
| Qwen2.5-1.5B | AR decoder | 28 | 1.018 | 0.97-1.06 | 0.68 | no | 0.576 | 0.357 | 14.534 |
| GPT-2 XL | AR decoder | 48 | 0.885 | 0.87-0.89 | 1.13 | no | 0.898 | 0.415 | 4.966 |
