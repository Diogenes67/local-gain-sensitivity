Protocol fullseq-random-block-float32-fd

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.504 | 0.43-0.57 | 2.22 | yes | 0.573 | 0.552 | 116.377 |
| Pythia-160M | AR decoder | 12 | 0.597 | 0.53-0.66 | 1.83 | yes | 0.327 | 0.481 | 59.608 |
| Pythia-410M | AR decoder | 24 | 0.888 | 0.85-0.93 | 1.28 | no | 1.074 | 0.032 | -5.724 |
| Pythia-1B | AR decoder | 16 | 0.535 | 0.47-0.59 | 1.73 | yes | 0.908 | 0.500 | 36.581 |
| Pythia-1.4B | AR decoder | 24 | 0.517 | 0.46-0.59 | 3.06 | yes | 0.196 | 0.634 | 134.440 |
| Qwen2.5-1.5B | AR decoder | 28 | 0.145 | 0.13-0.16 | 1.61 | yes | 0.601 | 0.954 | 1457.914 |
| GPT-2 XL | AR decoder | 48 | 0.831 | 0.76-0.91 | 1.25 | no | 0.758 | 0.385 | 20.278 |
