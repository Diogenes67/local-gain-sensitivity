Protocol incontext-random-block-float32

| Model | Family | Blocks | R_ex0 | 95% CI | uptick | HG | R_vertex | C_ex0 | a_ex0 |
|---|---|---|---|---|---|---|---|---|---|
| GPT-2 124M | AR decoder | 12 | 0.719 | 0.70-0.74 | 1.46 | yes | 0.790 | 0.295 | 8.646 |
| Pythia-160M | AR decoder | 12 | 0.688 | 0.67-0.72 | 2.09 | yes | 0.753 | 0.354 | 22.149 |
| Pythia-410M | AR decoder | 24 | 0.835 | 0.80-0.86 | 1.31 | no | 0.895 | 0.297 | 5.615 |
| Pythia-1B | AR decoder | 16 | 0.744 | 0.73-0.76 | 1.31 | yes | 0.798 | 0.330 | 14.243 |
| Llama-3.2-1B | AR decoder | 16 | 0.983 | 0.93-1.04 | 0.97 | no | 0.909 | 0.105 | 10.590 |
| Pythia-1.4B | AR decoder | 24 | 0.768 | 0.74-0.79 | 1.42 | yes | 0.847 | 0.263 | 7.246 |
| Qwen2.5-1.5B | AR decoder | 28 | 0.896 | 0.88-0.91 | 1.02 | no | 0.964 | 0.322 | 9.070 |
| GPT-2 XL | AR decoder | 48 | 0.952 | 0.94-0.97 | 1.00 | no | 0.838 | 0.352 | 3.918 |
| Pythia-6.9B | AR decoder | 32 | 0.824 | 0.80-0.85 | 1.17 | no | 0.790 | 0.304 | 8.290 |
| Qwen2.5-7B | AR decoder | 28 | 0.709 | 0.69-0.72 | 1.48 | yes | 0.656 | 0.490 | 24.085 |
| ConvNeXt-tiny | ConvNet (vision) | 18 | 0.334 | 0.33-0.34 | 3.15 | yes | 0.683 | 0.420 | -14.523 |
| ConvNeXt-base | ConvNet (vision) | 36 | 0.375 | 0.37-0.38 | 2.76 | yes | 0.233 | 0.312 | 41.782 |
| Mamba-130M | SSM | 24 | 0.344 | 0.32-0.37 | 4.72 | yes | 0.475 | 0.806 | 53.299 |
